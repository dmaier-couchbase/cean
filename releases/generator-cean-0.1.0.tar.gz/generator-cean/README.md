# GENERATOR-CEAN

This is the main YEOMAN generator for the CEAN stack.
