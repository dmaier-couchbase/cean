/**
 * Constructor
 */
function T<%= _.camelize(name) %>(httpService)
{
  this.httpService = httpService;   
}

/**
 * Service client function
 */
T<%= _.camelize(name) %>.prototype.yourcall = function(id)
{
    //Your service code here
    //...
}
